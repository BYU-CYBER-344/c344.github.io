#!/bin/bash
# check.cgi - returns 200 if "pw" equals "un" + "-9455", otherwise 401.
# Expects: POST, Content-Type: application/x-www-form-urlencoded, body: un=...&pw=...

respond() {  # respond <status line> <body text>
    printf 'Status: %s\r\n' "$1"
    printf 'Content-Type: text/plain\r\n'
    printf 'Cache-Control: no-store\r\n\r\n'
    printf '%s\n' "$2"
    exit 0
}

# Decode application/x-www-form-urlencoded text (ASCII/byte-oriented)
urldecode() {
    local s="${1//+/ }"
    s="${s//\\/\\\\}"          # protect literal backslashes from printf %b
    printf '%b' "${s//%/\\x}"  # turn %XX into \xXX
}


# Only POST is allowed
[[ "$REQUEST_METHOD" == "POST" ]] || respond "405 Method Not Allowed" "POST required"

# Validate and cap the body length (4 KB is plenty for this lab)
len="${CONTENT_LENGTH:-0}"
[[ "$len" =~ ^[0-9]+$ ]] && (( len > 0 && len <= 4096 )) \
    || respond "400 Bad Request" "Missing or invalid body"

body=$(head -c "$len")

# Parse key=value pairs
un="" pw=""
IFS='&' read -ra pairs <<< "$body"
for pair in "${pairs[@]}"; do
    key=$(urldecode "${pair%%=*}")
    val=$(urldecode "${pair#*=}")
    case "$key" in
        un) un="$val" ;;
        pw) pw="$val" ;;
    esac
done

[[ -n "$un" && -n "$pw" ]] || respond "400 Bad Request" "un and pw are required"

# The actual check (quoted RHS = literal comparison, not a glob pattern)
if [[ "$pw" == "${un}-9455" ]]; then
    respond "200 OK" "OK"
else
    respond "401 Unauthorized" "Unauthorized"
fi
